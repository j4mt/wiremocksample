#!/usr/bin/env bash

java -cp 'lib/*' com.github.tomakehurst.wiremock.standalone.WireMockServerRunner\
    `#--https-port 8443 --https-keystore server/keystore.jks --keystore-password changeit`\
    --port 8443\
    --verbose --no-request-journal --local-response-templating